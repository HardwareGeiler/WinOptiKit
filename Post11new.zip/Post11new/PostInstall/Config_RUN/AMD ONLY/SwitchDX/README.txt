1. Open the folder.
2. Run Radeon DX Configurator.exe.
3. If it doesn't open, download and install this runtime: [Windows Desktop Runtime](https://download.visualstudio.microsoft.com/download/pr/3ef3cd0c-8c7f-4146-bd8d-589d748b997e/3477d059f8fe5cceb5166b367d7995c6/windowsdesktop-runtime-6.0.27-win-x64.exe).
4. Click "Yes" on the backup popup.
5. Click "Set Regular DX11" and restart.
6. Test if the game runs smoother; you may additionally confirm with capframex.
7. If the performance is not improved, restore to the backup.

Password: AMD

If you don't want to run the exe, here's a guide on how to do it manually: https://nimez-dxswitch.pages.dev/NzDXSwitch
