iwr -useb https://christitus.com/win | iex
